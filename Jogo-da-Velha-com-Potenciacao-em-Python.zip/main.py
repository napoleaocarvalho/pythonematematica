import random
#Napoleão Carvalho
#IFMA Campus Buriticupu
#Metodologia do Ensino de Matemática
#Atividade 1
a=random.randint(1,2)
b=random.randint(17,18)
c=random.randint(13,14)
d=random.randint(7,8)
e=random.randint(15,16)
f=random.randint(11,12)
g=random.randint(5,6)
h=random.randint(9,10)
i=random.randint(3,4)
z=2
print('\nNúmeros maiores ou iguais a 10 eleve ao quadrado\nNúmeros menores que 10 eleve ao cubo!')
print('''Cada espaço corresponde a uma letra respectivamente\n\n------------------
| a | b | c |
------------------
| d | e | f |
------------------
| g | h | i |''')

print('''\n\n------------------
| {} | {} | {} |
------------------
| {} | {} | {} |
------------------
| {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
while z<=30:
  letra=input('\n\nDigite a letra que você quer preencher: ')
  if letra=='a':
      resultado1=int(input('Qual o resultado? '))
      if resultado1==a**3:
        if z%2==0:
          a='X'
          print ('''\n\n------------------
        | {} | {} | {} |
        ------------------
        | {} | {} | {} |
        ------------------
        | {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
        else:
          a='O'
          print ('''\n\n------------------
        | {} | {} | {} |
        ------------------
        | {} | {} | {} |
        ------------------
        | {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
      else:
        print('Você perdeu!')
  elif letra=='b':
    resultado2=int(input('Qual o resultado? '))
    if resultado2==b**2:
      if z%2==0:
        b='X'
        print('''\n\n------------------
| {} | {} | {} |
------------------
| {} | {} | {} |
------------------
| {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
      else:
        b='O'
        print('''\n\n------------------
| {} | {} | {} |
------------------
| {} | {} | {} |
------------------
| {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
    else:
      print('Você perdeu!')
  elif letra=='c':
    resultado3=int(input('Qual o resultado? '))
    if resultado3==c**2:
      if z%2==0:
        c='X'
        print('''\n\n------------------
| {} | {} | {} |
------------------
| {} | {} | {} |
------------------
| {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
      else:
        c='O'
        print('''\n\n------------------
| {} | {} | {} |
------------------
| {} | {} | {} |
------------------
| {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
    else:
      print('Você perdeu!')
  elif letra=='d':
    resultado4=int(input('Qual o resultado? '))
    if resultado4==d**3:
      if z%2==0:
        d='X'
        print('''\n\n------------------
| {} | {} | {} |
------------------
| {} | {} | {} |
------------------
| {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
      else:
        d='O'
        print('''\n\n------------------
| {} | {} | {} |
------------------
| {} | {} | {} |
------------------
| {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
    else:
      print('Você perdeu!')
  elif letra=='e':
    resultado5=int(input('Qual o resultado? '))
    if resultado5==e**2:
      if z%2==0:
        e='X'
        print('''\n\n------------------
| {} | {} | {} |
------------------
| {} | {} | {} |
------------------
| {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
      else:
        e='O'
        print('''\n\n------------------
| {} | {} | {} |
------------------
| {} | {} | {} |
------------------
| {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
    else:
      print('Você perdeu!')
  elif letra=='f':
    resultado6=int(input('Qual o resultado? '))
    if resultado6==f**2:
      if z%2==0:
        f='X'
        print('''\n\n------------------
| {} | {} | {} |
------------------
| {} | {} | {} |
------------------
| {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
      else:
        f='O'
        print('''\n\n------------------
| {} | {} | {} |
------------------
| {} | {} | {} |
------------------
| {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i)) 
    else:
      print('Você perdeu!')
  elif letra=='g':
    resultado7=int(input('Qual o resultado? '))
    if resultado7==g**3:
      if z%2==0:
        g='X'
        print('''\n\n------------------
| {} | {} | {} |
------------------
| {} | {} | {} |
------------------
| {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
      else:
        g='O'
        print('''\n\n------------------
| {} | {} | {} |
------------------
| {} | {} | {} |
------------------
| {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
    else:
      print('Você perdeu!')
  elif letra=='h':
    resultado7=int(input('Qual o resultado? '))
    if resultado7==h**3:
      if z%2==0:
        h='X'
        print('''\n\n------------------
| {} | {} | {} |
------------------
| {} | {} | {} |
------------------
| {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
      else:
        h='O'
        print('''\n\n------------------
| {} | {} | {} |
------------------
| {} | {} | {} |
------------------
| {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
    else:
      print('Você perdeu!')
  elif letra=='i':
    resultado8=int(input('Qual o resultado? '))
    if resultado8==i**3:
      if z%2==0:
        i='X'
        print('''\n\n------------------
| {} | {} | {} |
------------------
| {} | {} | {} |
------------------
| {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
      else:
        i='O'
        print('''\n\n------------------
| {} | {} | {} |
------------------
| {} | {} | {} |
------------------
| {} | {} | {} |'''.format(a,b,c,d,e,f,g,h,i))
    else:
      print('Você perdeu!')
  z=z+1


